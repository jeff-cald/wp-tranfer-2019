<?php

if (!defined('ABSPATH')) die('No direct access allowed');

add_filter('wpo_cache_cookies', 'wpo_cache_cookies_add_wc_currency_converter');
add_filter('wpo_cache_query_variables', 'wpo_cache_query_variables_woocommerce');

/**
 * Filter GET query variable names used for building cache file name.
 *
 * @param array $variables
 *
 * @return array
 */
function wpo_cache_query_variables_woocommerce($variables) {

	// check if active multi currency plugin.
	if (defined('WCML_VERSION')) {
		$variables[] = 'wcmlc';
	}

	// check if active WPML plugin.
	if (defined('ICL_SITEPRESS_VERSION')) {
		$variables[] = 'lang';
	}

	return $variables;
}

/**
 * Filter COOKIE variable names used for building cache file name.
 *
 * @param array $cookies
 *
 * @return array
 */
function wpo_cache_cookies_add_wc_currency_converter($cookies) {

	if (class_exists('WC_Currency_Converter')) {
		$cookies[] = 'woocommerce_current_currency';
	}

	return $cookies;
}
